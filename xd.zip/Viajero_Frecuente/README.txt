Viajero Frecuente - Flask + MySQL

como correrlo:
1. ejecutar flask_app/bd/base.sql en MySQL Workbench (crea la bd viajero_frecuente)
2. revisar usuario y contraseña de MySQL en flask_app/config/mysqlconnection.py
3. pipenv install flask flask-bcrypt pymysql
4. pipenv shell
5. python server.py
6. abrir http://localhost:5000

rutas:
/                -> registro e inicio de sesion
/dashboard       -> lista de viajes
/nuevo           -> crear viaje
/ver/<id>        -> detalle del viaje + viajeros (unirme / cancelar)
/editar/<id>     -> editar viaje (solo el organizador)
/borrar/<id>     -> borrar viaje (solo el organizador)
/logout          -> cerrar sesion
